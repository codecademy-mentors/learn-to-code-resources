$(document).ready(function(){
  $('.modal').modal('show');
});
